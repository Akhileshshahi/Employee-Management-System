This project is of JDBC with java this is very basic project this is menu driven program and this takes input through command line also show output through the command line
